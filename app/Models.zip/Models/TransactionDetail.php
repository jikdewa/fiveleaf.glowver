<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransactionDetail extends Model
{   
    protected $fillable = [
        'transaction_id',
        'product_id',
        'quantity',
        'cost_price',
        'selling_price',
        'subtotal',
    ];
    public function transaction()
    {
        return $this->belongsTo(Transaction::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
